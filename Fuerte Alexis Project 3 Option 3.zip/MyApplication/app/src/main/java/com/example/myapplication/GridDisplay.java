package com.example.myapplication;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.Toast;

public class GridDisplay extends AppCompatActivity {

    //Variable declarations
    EditText date, dailyWeight, goalWeight;
    Button insert, update, delete, view, logout;
    Switch enable;
    WeightData DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {//creates every edit text field and button
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_display);
        date = findViewById(R.id.date);
        dailyWeight = findViewById(R.id.dailyWeight);
        goalWeight = findViewById(R.id.goalWeight);
        insert = findViewById(R.id.buttonInsert);
        update = findViewById(R.id.buttonUpdate);
        delete = findViewById(R.id.buttonDelete);
        view = findViewById(R.id.buttonView);
        logout = findViewById(R.id.logout);
        enable = findViewById(R.id.switchEnable);
        DB = new WeightData(this);


        insert.setOnClickListener(new View.OnClickListener() {//onclick for weigh in. takes data for all 3 fields
            @Override
            public void onClick(View view) {//provides success/fail notifications
                String user = UserData.getPusername();
                String date2 = date.getText().toString();
                String weighIn = dailyWeight.getText().toString();
                String goal = goalWeight.getText().toString();

                Boolean checkinsertdata = DB.insertuserdata(date2, user, weighIn, goal);
                if (checkinsertdata == true)
                    Toast.makeText(GridDisplay.this, "Entry Successfully Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(GridDisplay.this, "Entry Failed", Toast.LENGTH_SHORT).show();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {//on click for update weigh-in
            @Override
            public void onClick(View view) {
                String user = UserData.getPusername();
                String dateText = date.getText().toString();
                String dailyWeightText = dailyWeight.getText().toString();
                String goalWeightText = goalWeight.getText().toString();

                Boolean checkupdatedata = DB.updateuserdata(dateText, dailyWeightText, goalWeightText);
                if (checkupdatedata == true)
                    Toast.makeText(GridDisplay.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(GridDisplay.this, "Update Failed", Toast.LENGTH_SHORT).show();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {//on click for delete entry
            @Override
            public void onClick(View view) {
                String dateText = date.getText().toString();
                Boolean checkdeletedata = DB.deleteuserdata(dateText);
                if (checkdeletedata == true)
                    Toast.makeText(GridDisplay.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(GridDisplay.this, "Delete Failed", Toast.LENGTH_SHORT).show();
            }
        });

        view.setOnClickListener(new View.OnClickListener() {//on click for displaying grid as toast message
            @Override
            public void onClick(View view) {
                Cursor res = DB.getData(UserData.getPusername());
                if (res.getCount() == 0) {
                    Toast.makeText(GridDisplay.this, "No Entry", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("Date: " + res.getString(0) + "\n");
                    buffer.append("User: " + res.getString(1) + "\n");
                    buffer.append("Weight: " + res.getString(2) + "\n");
                    buffer.append("Goal Weight: " + res.getString(3) + "\n\n");
                }


                AlertDialog.Builder builder = new AlertDialog.Builder(GridDisplay.this);
                builder.setCancelable(true);
                builder.setTitle("All Entries");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });

        logout.setOnClickListener(new View.OnClickListener() {//on click for returning to the login activity
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);//Intent takes you to login screen
                startActivity(intent);
            }
        });


        enable.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {//on check to see if the switch was toggled, and displays a message if it is on
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                String dayWeightText = dailyWeight.getText().toString();
                String goalWeightText = goalWeight.getText().toString();
                if(isChecked){
                    if(dayWeightText.equals(goalWeightText)) {
                        Toast.makeText(GridDisplay.this, "SMS Enabled", Toast.LENGTH_SHORT).show();
                    }
                }
            }




        });
    }


}