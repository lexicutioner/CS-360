package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    //Declaring variables
    EditText username, password;
    Button createAccount;
    Button logIn;
    UserData DB;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Linking xml to Java
        username=(EditText) findViewById(R.id.username);
        password=(EditText) findViewById(R.id.password);
        logIn = (Button) findViewById(R.id.logIn);
        createAccount = (Button) findViewById(R.id.createAccount);
        //Create new UserData object
        DB = new UserData(this);

        //Setting OnClick functionality
        logIn.setOnClickListener(new View.OnClickListener(){//onclick listener for sign in button on sign in screen
            @Override
            public void onClick(View v){
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals(""))
                    Toast.makeText(MainActivity.this, "All fields Required", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkuserpass= DB.checkusernamepassword(user, pass);
                    if(checkuserpass==true){
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        UserData.setPusername(user);
                        System.out.println("User is: " + UserData.getPusername());
                        Intent intent = new Intent(getApplicationContext(),GridDisplay.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CreateAccountActivity.class);
                startActivity(intent);
            }
        });
    }
}