package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class CreateAccountActivity extends AppCompatActivity {
    EditText username2, password2, confirmPassword;
    Button signup, login;
    UserData DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_acc);
        username2=(EditText) findViewById(R.id.username2);
        password2=(EditText) findViewById(R.id.password2);
        confirmPassword = (EditText) findViewById((R.id.confirmPassword));
        signup=(Button) findViewById(R.id.createAccount);
        login=(Button) findViewById(R.id.logIn);
        DB = new UserData(this);


        signup.setOnClickListener(new View.OnClickListener() {//onclick listener for the create account button
            @Override
            public void onClick(View view) {
                String user= username2.getText().toString();
                String pass= password2.getText().toString();
                String repass= confirmPassword.getText().toString();


                if(user.equals("") || pass.equals("") || repass.equals(""))//conditions
                    Toast.makeText(CreateAccountActivity.this, "All fields Required", Toast.LENGTH_SHORT).show();//All Toast messages are popup responses for when information is submitted
                else{
                    if(pass.equals(repass)){
                        Boolean checkuser = DB.checkusername(user);
                        if(checkuser == false) {
                            Boolean insert = DB.insertData(user,pass);
                            if (insert == true) {
                                Toast.makeText(CreateAccountActivity.this,"Registered Successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), GridDisplay.class);//Intent takes you to Dashboard
                                startActivity(intent);
                            } else {
                                Toast.makeText(CreateAccountActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            Toast.makeText(CreateAccountActivity.this, "User already Exists", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(CreateAccountActivity.this, "Passwords are not Matching", Toast.LENGTH_SHORT).show();
                    }
                }
                login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent= new Intent(getApplicationContext(), MainActivity.class);//Intent takes you to Sign In screen
                        startActivity(intent);
                    }
                });
            }


        });
    }
}

