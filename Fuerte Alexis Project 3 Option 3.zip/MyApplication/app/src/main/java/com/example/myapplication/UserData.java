package com.example.myapplication;

import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;

        import androidx.annotation.Nullable;

public class UserData extends SQLiteOpenHelper {

    //Global static variable used to link username to database
    public static String Pusername;

    //New UserData object
    public UserData(@Nullable Context context) {
        super(context, "login.db", null, 1);
    }



    @Override//function to create new entry
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create table users(username TEXT primary key, password TEXT)");
    }

    @Override//function to edit data
    public void onUpgrade(SQLiteDatabase MyDB, int oldVersion, int newVersion){
        MyDB.execSQL("drop table if exists users");

    }
    public Boolean insertData(String username, String password){//function to insert data
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username", username);
        Pusername = username;
        values.put("password", password);


        long result= MyDB.insert("users", null, values);
        if(result==1) return false;
        else
            return true;
    }
    public Boolean checkusername(String username) {//function to check username
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from users where username=?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public Boolean checkusernamepassword(String username, String password){//function to check username with password
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from users where username=? and password=?", new String[] {username,password});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }

    public static String getPusername(){
        return Pusername;
    }//returns the username inputted during the login phase



    public static void setPusername(String usern){
        Pusername = usern;
    }//sets Pusername to the username inputted during the login phase

}
