package com.example.myapplication;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class WeightData extends SQLiteOpenHelper {



    //New WeightData object
    public WeightData(@Nullable Context context) {
        super(context, "Userdata.db", null, 1);
    }

    //creates table for weight database
    @Override
    public void onCreate(SQLiteDatabase MyDB2) {//the date acts as the primary key to create different entries
        MyDB2.execSQL("create Table userDetails( date TEXT primary key, user TEXT, dailyWeight TEXT, goalWeight TEXT)");

    }

    @Override//Called if database version is updated
    public void onUpgrade(SQLiteDatabase MyDB2, int i, int i1) {
        MyDB2.execSQL("drop Table if exists userDetails");
        onCreate(MyDB2);

    }

    @Override//Called if database version is downgraded
    public void onDowngrade(SQLiteDatabase MyDB2, int i, int i1) {
        onUpgrade(MyDB2, i, i1);

    }

    public Boolean insertuserdata( String date, String user, String dailyWeight, String goalWeight) {//Populates date, user, weight, and goal weight for the entry
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        user = UserData.getPusername();
        System.out.println(user);
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", date);
        contentValues.put("user", user);
        contentValues.put("dailyweight", dailyWeight);
        contentValues.put("goalweight", goalWeight);
        long result = MyDB2.insert("Userdetails", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }


    public Boolean updateuserdata(String date, String dailyWeight, String goalWeight) {//edit the data for an entry of a given date
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("dailyweight", dailyWeight);
        contentValues.put("goalweight", goalWeight);
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails where date = ?", new String[]{date});
        if (cursor.getCount() > 0) {
            long result = MyDB2.update("Userdetails", contentValues, "date=?", new String[]{date});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }


    public Boolean deleteuserdata(String date) {//delete an entry for a given date
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails where date = ?", new String[]{date});
        if (cursor.getCount() > 0) {
            long result = MyDB2.delete("Userdetails", "date=?", new String[]{date});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }


    public Cursor getData(String CUser) {//View the grid specific to the current user (CUser) and displays by date in descending order
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails where user = ? ORDER BY date DESC",new String[]{CUser});
        return cursor;

    }
}